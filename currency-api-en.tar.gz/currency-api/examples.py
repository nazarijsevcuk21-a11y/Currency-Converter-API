"""
Приклади використання Currency Converter API
"""

import requests
import json


BASE_URL = "http://localhost:5000"


def example_1_basic_conversion():
    """Приклад 1: Базова конвертація"""
    print("\n=== Приклад 1: Конвертація USD в EUR ===")
    
    response = requests.get(
        f"{BASE_URL}/api/convert",
        params={
            "amount": 100,
            "from": "USD",
            "to": "EUR"
        }
    )
    
    data = response.json()
    
    if data['success']:
        print(f"Сума: ${data['query']['amount']}")
        print(f"Результат: €{data['result']}")
        print(f"Курс: {data['rate']}")
    else:
        print(f"Помилка: {data['error']}")


def example_2_multiple_conversions():
    """Приклад 2: Декілька конвертацій"""
    print("\n=== Приклад 2: Різні валюти ===")
    
    conversions = [
        (1000, "USD", "UAH"),
        (500, "EUR", "GBP"),
        (10000, "JPY", "USD"),
    ]
    
    for amount, from_curr, to_curr in conversions:
        response = requests.get(
            f"{BASE_URL}/api/convert",
            params={
                "amount": amount,
                "from": from_curr,
                "to": to_curr
            }
        )
        
        data = response.json()
        if data['success']:
            print(f"{amount} {from_curr} = {data['result']} {to_curr}")


def example_3_get_all_rates():
    """Приклад 3: Всі курси"""
    print("\n=== Приклад 3: Всі курси валют ===")
    
    response = requests.get(f"{BASE_URL}/api/rates")
    data = response.json()
    
    if data['success']:
        print(f"Базова валюта: {data['base']}")
        print(f"Всього валют: {len(data['rates'])}")
        print("\nПриклади курсів:")
        
        popular = ['EUR', 'GBP', 'JPY', 'UAH', 'PLN']
        for currency in popular:
            if currency in data['rates']:
                print(f"  1 USD = {data['rates'][currency]:.4f} {currency}")


def example_4_list_currencies():
    """Приклад 4: Список валют"""
    print("\n=== Приклад 4: Доступні валюти ===")
    
    response = requests.get(f"{BASE_URL}/api/currencies")
    data = response.json()
    
    if data['success']:
        print(f"Всього валют: {data['count']}")
        print(f"Перші 20: {', '.join(data['currencies'][:20])}")


def example_5_post_request():
    """Приклад 5: POST запит"""
    print("\n=== Приклад 5: POST запит ===")
    
    response = requests.post(
        f"{BASE_URL}/api/convert",
        json={
            "amount": 250,
            "from": "GBP",
            "to": "USD"
        }
    )
    
    data = response.json()
    
    if data['success']:
        print(f"£{data['query']['amount']} = ${data['result']}")
        print(f"Курс: {data['rate']:.6f}")


def example_6_error_handling():
    """Приклад 6: Обробка помилок"""
    print("\n=== Приклад 6: Обробка помилок ===")
    
    # Невірна валюта
    response = requests.get(
        f"{BASE_URL}/api/convert",
        params={
            "amount": 100,
            "from": "XXX",
            "to": "USD"
        }
    )
    
    data = response.json()
    print(f"Тест невірної валюти: {data['error']}")
    
    # Невірна сума
    response = requests.get(
        f"{BASE_URL}/api/convert",
        params={
            "amount": -100,
            "from": "USD",
            "to": "EUR"
        }
    )
    
    data = response.json()
    print(f"Тест невірної суми: {data['error']}")


def example_7_health_check():
    """Приклад 7: Перевірка статусу"""
    print("\n=== Приклад 7: Health Check ===")
    
    response = requests.get(f"{BASE_URL}/api/health")
    data = response.json()
    
    print(f"Статус: {data['status']}")
    print(f"Доступно валют: {data['currencies_available']}")
    print(f"Останнє оновлення: {data['last_update']}")


def example_8_calculator():
    """Приклад 8: Калькулятор валют"""
    print("\n=== Приклад 8: Інтерактивний калькулятор ===")
    
    print("Введіть дані для конвертації (або 'exit' для виходу):")
    
    while True:
        try:
            amount = input("Сума: ")
            if amount.lower() == 'exit':
                break
            
            amount = float(amount)
            from_curr = input("З валюти (напр. USD): ").upper()
            to_curr = input("В валюту (напр. EUR): ").upper()
            
            response = requests.get(
                f"{BASE_URL}/api/convert",
                params={
                    "amount": amount,
                    "from": from_curr,
                    "to": to_curr
                }
            )
            
            data = response.json()
            
            if data['success']:
                print(f"\n✅ Результат: {amount} {from_curr} = {data['result']} {to_curr}")
                print(f"   Курс: 1 {from_curr} = {data['rate']:.6f} {to_curr}\n")
            else:
                print(f"\n❌ Помилка: {data['error']}\n")
                
        except ValueError:
            print("❌ Невірний формат суми\n")
        except KeyboardInterrupt:
            print("\n\nВихід...")
            break
        except Exception as e:
            print(f"❌ Помилка: {e}\n")


def run_all_examples():
    """Запустити всі приклади"""
    print("="*60)
    print("Currency Converter API - Приклади використання")
    print("="*60)
    
    examples = [
        example_1_basic_conversion,
        example_2_multiple_conversions,
        example_3_get_all_rates,
        example_4_list_currencies,
        example_5_post_request,
        example_6_error_handling,
        example_7_health_check,
    ]
    
    for example in examples:
        try:
            example()
        except Exception as e:
            print(f"Помилка в {example.__name__}: {e}")
    
    print("\n" + "="*60)
    
    # Інтерактивний калькулятор (опціонально)
    run_calculator = input("\nЗапустити інтерактивний калькулятор? (y/n): ")
    if run_calculator.lower() == 'y':
        example_8_calculator()


if __name__ == "__main__":
    try:
        run_all_examples()
    except requests.exceptions.ConnectionError:
        print("\n❌ Помилка: API сервер не запущено!")
        print("Запустіть сервер: python app.py")
