"""
Currency Converter API - Flask REST API для конвертації валют
Використовує актуальні курси з відкритих API
"""

from flask import Flask, jsonify, request, render_template_string
import requests
from datetime import datetime, timedelta
from functools import lru_cache
import logging

# Налаштування
app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False
app.config['JSONIFY_PRETTYPRINT_REGULAR'] = True

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Кешування курсів на 1 годину
CACHE_DURATION = timedelta(hours=1)
cache_time = None
cached_rates = None

# API для курсів валют (безкоштовний)
EXCHANGE_API_URL = "https://api.exchangerate-api.com/v4/latest/USD"
BACKUP_API_URL = "https://open.er-api.com/v6/latest/USD"


class CurrencyConverter:
    """Клас для конвертації валют"""
    
    def __init__(self):
        self.rates = {}
        self.base_currency = "USD"
        self.last_update = None
    
    def fetch_rates(self) -> dict:
        """Отримує актуальні курси валют"""
        try:
            # Спробуємо основний API
            response = requests.get(EXCHANGE_API_URL, timeout=5)
            response.raise_for_status()
            data = response.json()
            
            self.rates = data.get('rates', {})
            self.base_currency = data.get('base', 'USD')
            self.last_update = datetime.now()
            
            logger.info(f"Курси оновлено: {len(self.rates)} валют")
            return self.rates
            
        except Exception as e:
            logger.warning(f"Помилка основного API: {e}")
            
            # Спробуємо резервний API
            try:
                response = requests.get(BACKUP_API_URL, timeout=5)
                response.raise_for_status()
                data = response.json()
                
                self.rates = data.get('rates', {})
                self.base_currency = data.get('base', 'USD')
                self.last_update = datetime.now()
                
                logger.info(f"Використано резервний API: {len(self.rates)} валют")
                return self.rates
                
            except Exception as e2:
                logger.error(f"Помилка резервного API: {e2}")
                return {}
    
    def get_rates(self, force_refresh: bool = False) -> dict:
        """Отримує курси (з кешем)"""
        global cache_time, cached_rates
        
        # Перевіряємо кеш
        if not force_refresh and cache_time and cached_rates:
            if datetime.now() - cache_time < CACHE_DURATION:
                logger.info("Використовуємо кешовані курси")
                return cached_rates
        
        # Оновлюємо курси
        rates = self.fetch_rates()
        if rates:
            cache_time = datetime.now()
            cached_rates = rates
        
        return rates
    
    def convert(self, amount: float, from_currency: str, 
                to_currency: str) -> dict:
        """Конвертує валюту"""
        from_currency = from_currency.upper()
        to_currency = to_currency.upper()
        
        # Отримуємо курси
        rates = self.get_rates()
        
        if not rates:
            return {
                'success': False,
                'error': 'Не вдалось отримати курси валют'
            }
        
        # Перевіряємо валюти
        if from_currency not in rates:
            return {
                'success': False,
                'error': f'Невідома валюта: {from_currency}'
            }
        
        if to_currency not in rates:
            return {
                'success': False,
                'error': f'Невідома валюта: {to_currency}'
            }
        
        # Конвертуємо через USD
        if from_currency == "USD":
            result = amount * rates[to_currency]
        elif to_currency == "USD":
            result = amount / rates[from_currency]
        else:
            # Спочатку в USD, потім в цільову валюту
            amount_in_usd = amount / rates[from_currency]
            result = amount_in_usd * rates[to_currency]
        
        # Розраховуємо курс
        rate = result / amount if amount != 0 else 0
        
        return {
            'success': True,
            'query': {
                'from': from_currency,
                'to': to_currency,
                'amount': amount
            },
            'result': round(result, 2),
            'rate': round(rate, 6),
            'timestamp': datetime.now().isoformat()
        }
    
    def get_available_currencies(self) -> list:
        """Повертає список доступних валют"""
        rates = self.get_rates()
        return sorted(rates.keys()) if rates else []


# Глобальний конвертер
converter = CurrencyConverter()


# HTML шаблон для головної сторінки
HOME_PAGE = """
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Currency Converter API</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #333;
        }
        .container {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        h1 {
            color: #667eea;
            text-align: center;
            margin-bottom: 10px;
        }
        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
        }
        .endpoint {
            background: #f8f9fa;
            border-left: 4px solid #667eea;
            padding: 15px;
            margin: 15px 0;
            border-radius: 5px;
        }
        .endpoint h3 {
            margin-top: 0;
            color: #667eea;
        }
        .method {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 3px;
            font-weight: bold;
            font-size: 12px;
            margin-right: 10px;
        }
        .get { background: #28a745; color: white; }
        .post { background: #007bff; color: white; }
        code {
            background: #e9ecef;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
        }
        pre {
            background: #2d2d2d;
            color: #f8f8f2;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
        }
        .example {
            margin-top: 10px;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        .stat-card h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            opacity: 0.9;
        }
        .stat-card .value {
            font-size: 28px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>💱 Currency Converter API</h1>
        <p class="subtitle">Безкоштовний REST API для конвертації валют</p>
        
        <div class="stats">
            <div class="stat-card">
                <h3>Валют</h3>
                <div class="value">{{ currencies_count }}</div>
            </div>
            <div class="stat-card">
                <h3>Оновлено</h3>
                <div class="value">{{ last_update }}</div>
            </div>
            <div class="stat-card">
                <h3>Статус</h3>
                <div class="value">✅ Online</div>
            </div>
        </div>
        
        <h2>📚 API Endpoints</h2>
        
        <div class="endpoint">
            <h3><span class="method get">GET</span> /api/convert</h3>
            <p>Конвертує валюту</p>
            <p><strong>Параметри:</strong></p>
            <ul>
                <li><code>amount</code> - сума (обов'язково)</li>
                <li><code>from</code> - валюта джерела (обов'язково)</li>
                <li><code>to</code> - цільова валюта (обов'язково)</li>
            </ul>
            <div class="example">
                <strong>Приклад:</strong>
                <pre>GET /api/convert?amount=100&from=USD&to=EUR</pre>
            </div>
        </div>
        
        <div class="endpoint">
            <h3><span class="method post">POST</span> /api/convert</h3>
            <p>Конвертує валюту (POST)</p>
            <div class="example">
                <strong>Приклад:</strong>
                <pre>{
  "amount": 100,
  "from": "USD",
  "to": "EUR"
}</pre>
            </div>
        </div>
        
        <div class="endpoint">
            <h3><span class="method get">GET</span> /api/rates</h3>
            <p>Отримує всі курси валют</p>
            <div class="example">
                <strong>Приклад:</strong>
                <pre>GET /api/rates</pre>
            </div>
        </div>
        
        <div class="endpoint">
            <h3><span class="method get">GET</span> /api/currencies</h3>
            <p>Список доступних валют</p>
        </div>
        
        <h2>💻 Приклад використання</h2>
        <pre>import requests

response = requests.get(
    "http://localhost:5000/api/convert",
    params={
        "amount": 100,
        "from": "USD",
        "to": "EUR"
    }
)

print(response.json())</pre>
        
        <p style="text-align: center; margin-top: 30px; color: #666;">
            Created with ❤️ | <a href="https://github.com/yourusername">GitHub</a>
        </p>
    </div>
</body>
</html>
"""


# API Routes
@app.route('/')
def home():
    """Головна сторінка"""
    currencies = converter.get_available_currencies()
    last_update = converter.last_update.strftime("%H:%M") if converter.last_update else "N/A"
    
    return render_template_string(
        HOME_PAGE,
        currencies_count=len(currencies),
        last_update=last_update
    )


@app.route('/api/convert', methods=['GET', 'POST'])
def convert_currency():
    """Конвертація валюти"""
    try:
        if request.method == 'POST':
            data = request.get_json()
            amount = float(data.get('amount', 0))
            from_currency = data.get('from', '')
            to_currency = data.get('to', '')
        else:
            amount = float(request.args.get('amount', 0))
            from_currency = request.args.get('from', '')
            to_currency = request.args.get('to', '')
        
        # Валідація
        if not amount or amount <= 0:
            return jsonify({
                'success': False,
                'error': 'Невірна сума'
            }), 400
        
        if not from_currency or not to_currency:
            return jsonify({
                'success': False,
                'error': 'Вкажіть валюти (from та to)'
            }), 400
        
        # Конвертуємо
        result = converter.convert(amount, from_currency, to_currency)
        
        if result['success']:
            return jsonify(result), 200
        else:
            return jsonify(result), 400
            
    except ValueError:
        return jsonify({
            'success': False,
            'error': 'Невірний формат суми'
        }), 400
    except Exception as e:
        logger.error(f"Помилка конвертації: {e}")
        return jsonify({
            'success': False,
            'error': 'Внутрішня помилка сервера'
        }), 500


@app.route('/api/rates', methods=['GET'])
def get_rates():
    """Отримати всі курси"""
    base = request.args.get('base', 'USD').upper()
    
    rates = converter.get_rates()
    
    if not rates:
        return jsonify({
            'success': False,
            'error': 'Не вдалось отримати курси'
        }), 500
    
    return jsonify({
        'success': True,
        'base': base,
        'rates': rates,
        'timestamp': datetime.now().isoformat()
    }), 200


@app.route('/api/currencies', methods=['GET'])
def get_currencies():
    """Список валют"""
    currencies = converter.get_available_currencies()
    
    return jsonify({
        'success': True,
        'count': len(currencies),
        'currencies': currencies
    }), 200


@app.route('/api/health', methods=['GET'])
def health_check():
    """Перевірка статусу"""
    rates = converter.get_rates()
    
    return jsonify({
        'status': 'healthy' if rates else 'degraded',
        'currencies_available': len(rates),
        'last_update': converter.last_update.isoformat() if converter.last_update else None,
        'timestamp': datetime.now().isoformat()
    }), 200


@app.errorhandler(404)
def not_found(e):
    """404 помилка"""
    return jsonify({
        'success': False,
        'error': 'Endpoint не знайдено'
    }), 404


@app.errorhandler(500)
def server_error(e):
    """500 помилка"""
    return jsonify({
        'success': False,
        'error': 'Внутрішня помилка сервера'
    }), 500


if __name__ == '__main__':
    logger.info("🚀 Запуск Currency Converter API...")
    
    # Завантажуємо курси при старті
    converter.get_rates()
    
    # Запускаємо сервер
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True
    )
