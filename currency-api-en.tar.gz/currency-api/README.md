# 💱 Currency Converter API

REST API для конвертації валют з актуальними курсами. Побудований на Flask.

## ✨ Можливості

### 🔄 Конвертація валют
- Підтримка 160+ валют світу
- Актуальні курси в реальному часі
- GET та POST запити
- Точність до 6 знаків

### ⚡ Продуктивність
- Кешування курсів (1 година)
- Автоматичне оновлення
- Резервний API
- Швидкі відповіді

### 📊 Додатково
- Список всіх валют
- Всі курси валют
- Health check endpoint
- Красива веб-сторінка

## 🛠 Технології

- **Flask 3.0** - веб-фреймворк
- **requests** - HTTP клієнт
- **ExchangeRate-API** - джерело курсів

## 📦 Встановлення

```bash
git clone https://github.com/yourusername/currency-api.git
cd currency-api
pip install -r requirements.txt
```

## 🚀 Запуск

```bash
python app.py
```

Сервер буде доступний на `http://localhost:5000`

## 📚 API Endpoints

### 1. Конвертація валюти

**GET** `/api/convert`

**Параметри:**
- `amount` (float) - сума
- `from` (string) - валюта джерела
- `to` (string) - цільова валюта

**Приклад:**
```bash
curl "http://localhost:5000/api/convert?amount=100&from=USD&to=EUR"
```

**Відповідь:**
```json
{
  "success": true,
  "query": {
    "from": "USD",
    "to": "EUR",
    "amount": 100
  },
  "result": 92.15,
  "rate": 0.9215,
  "timestamp": "2024-11-27T10:30:00"
}
```

### 2. Конвертація (POST)

**POST** `/api/convert`

**Body:**
```json
{
  "amount": 100,
  "from": "USD",
  "to": "EUR"
}
```

**Приклад:**
```bash
curl -X POST http://localhost:5000/api/convert \
  -H "Content-Type: application/json" \
  -d '{"amount":100,"from":"USD","to":"EUR"}'
```

### 3. Всі курси валют

**GET** `/api/rates`

**Приклад:**
```bash
curl "http://localhost:5000/api/rates"
```

**Відповідь:**
```json
{
  "success": true,
  "base": "USD",
  "rates": {
    "EUR": 0.9215,
    "GBP": 0.7923,
    "JPY": 149.82,
    "UAH": 41.25,
    ...
  },
  "timestamp": "2024-11-27T10:30:00"
}
```

### 4. Список валют

**GET** `/api/currencies`

**Приклад:**
```bash
curl "http://localhost:5000/api/currencies"
```

**Відповідь:**
```json
{
  "success": true,
  "count": 162,
  "currencies": ["AED", "AFN", "ALL", ...]
}
```

### 5. Health Check

**GET** `/api/health`

**Відповідь:**
```json
{
  "status": "healthy",
  "currencies_available": 162,
  "last_update": "2024-11-27T10:30:00",
  "timestamp": "2024-11-27T10:31:00"
}
```

## 💻 Використання

### Python

```python
import requests

# Конвертація
response = requests.get(
    "http://localhost:5000/api/convert",
    params={
        "amount": 100,
        "from": "USD",
        "to": "EUR"
    }
)

data = response.json()
print(f"Результат: {data['result']} EUR")
```

### JavaScript

```javascript
fetch('http://localhost:5000/api/convert?amount=100&from=USD&to=EUR')
  .then(response => response.json())
  .then(data => {
    console.log(`Result: ${data.result} EUR`);
  });
```

### cURL

```bash
# GET запит
curl "http://localhost:5000/api/convert?amount=100&from=USD&to=EUR"

# POST запит
curl -X POST http://localhost:5000/api/convert \
  -H "Content-Type: application/json" \
  -d '{"amount":100,"from":"USD","to":"EUR"}'
```

## 🔍 Підтримувані валюти

Понад 160 валют, включаючи:

- 🇺🇸 **USD** - Долар США
- 🇪🇺 **EUR** - Євро
- 🇬🇧 **GBP** - Фунт стерлінгів
- 🇯🇵 **JPY** - Японська єна
- 🇺🇦 **UAH** - Українська гривня
- 🇵🇱 **PLN** - Польський злотий
- 🇨🇭 **CHF** - Швейцарський франк
- 🇨🇦 **CAD** - Канадський долар
- 🇦🇺 **AUD** - Австралійський долар
- 🇨🇳 **CNY** - Китайський юань

...та багато інших!

## 📊 Приклади

### Приклад 1: Базова конвертація

```python
import requests

response = requests.get(
    "http://localhost:5000/api/convert",
    params={"amount": 1000, "from": "USD", "to": "UAH"}
)

data = response.json()
print(f"$1000 = ₴{data['result']}")
```

### Приклад 2: Отримання всіх курсів

```python
response = requests.get("http://localhost:5000/api/rates")
rates = response.json()['rates']

for currency, rate in list(rates.items())[:5]:
    print(f"1 USD = {rate} {currency}")
```

### Приклад 3: Обробка помилок

```python
response = requests.get(
    "http://localhost:5000/api/convert",
    params={"amount": 100, "from": "INVALID", "to": "EUR"}
)

data = response.json()
if not data['success']:
    print(f"Помилка: {data['error']}")
```

## 🎨 Веб-інтерфейс

Відкрийте `http://localhost:5000` у браузері для доступу до веб-інтерфейсу з:
- Документацією API
- Актуальною статистикою
- Прикладами запитів

## 🔧 Конфігурація

### Зміна порту

```python
app.run(host='0.0.0.0', port=8080)
```

### Зміна тривалості кешу

```python
CACHE_DURATION = timedelta(hours=2)  # 2 години
```

### Використання іншого API

Замініть `EXCHANGE_API_URL` у файлі `app.py`:

```python
EXCHANGE_API_URL = "https://your-api-url.com/latest/USD"
```

## 📝 Структура відповіді

### Успішна конвертація

```json
{
  "success": true,
  "query": {
    "from": "USD",
    "to": "EUR",
    "amount": 100
  },
  "result": 92.15,
  "rate": 0.9215,
  "timestamp": "2024-11-27T10:30:00"
}
```

### Помилка

```json
{
  "success": false,
  "error": "Невідома валюта: XXX"
}
```

## 🚨 Коди помилок

- `400` - Невірні параметри запиту
- `404` - Endpoint не знайдено
- `500` - Внутрішня помилка сервера

## 🔐 Production готовність

### Для production використання:

1. Використовуйте gunicorn:
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

2. Налаштуйте CORS:
```python
from flask_cors import CORS
CORS(app)
```

3. Додайте rate limiting:
```python
from flask_limiter import Limiter
limiter = Limiter(app, default_limits=["100 per hour"])
```

4. Використовуйте HTTPS

## 📁 Структура проекту

```
currency-api/
├── app.py              # Головний файл Flask
├── examples.py         # Приклади використання
├── requirements.txt    # Залежності
├── README.md          # Документація
└── .gitignore
```

## 🤝 Внесок

1. Fork
2. Create branch: `git checkout -b feature/NewFeature`
3. Commit: `git commit -m 'Add NewFeature'`
4. Push: `git push origin feature/NewFeature`
5. Pull Request

## 📄 Ліцензія

MIT License

## 👤 Автор

[@your_username](https://github.com/your_username)

## 🙏 Подяки

- [ExchangeRate-API](https://www.exchangerate-api.com/) - безкоштовні курси валют
- [Flask](https://flask.palletsprojects.com/) - веб-фреймворк

---

⭐️ Поставте зірочку якщо проект корисний!
